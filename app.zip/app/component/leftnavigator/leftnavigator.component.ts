import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leftnavigator',
  templateUrl: './leftnavigator.component.html',
  styleUrls: ['./leftnavigator.component.css']
})
export class LeftnavigatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
