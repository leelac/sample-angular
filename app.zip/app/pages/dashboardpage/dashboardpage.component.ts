import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboardpage',
  templateUrl: './dashboardpage.component.html',
  styleUrls: ['./dashboardpage.component.css']
})
export class DashboardpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
