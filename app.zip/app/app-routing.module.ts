import { NgModule } from '@angular/core';
import { Route, RouterModule } from '@angular/router';
import { DashboardpageComponent } from './pages/dashboardpage/dashboardpage.component';

const routes: Route[] = [
  {path: 'dashboard', component: DashboardpageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
